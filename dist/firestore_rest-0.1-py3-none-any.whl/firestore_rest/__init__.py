from credentials import Credentials
from firestore import Firestore

credentials = Credentials()

firestore = Firestore()